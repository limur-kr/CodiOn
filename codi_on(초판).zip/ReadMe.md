# Codion (코디온)

**Closet × Weather × AI**  
내 옷장 기반으로 오늘 날씨에 가장 적합한 옷을 추천해  
**불필요한 구매를 줄이는** 코디 추천 서비스

---

## Overview
Codion은 사용자가 등록한 옷장 데이터(카테고리, 소재, 세탁/보관 등)와  
오늘/이번 주 기상 정보를 결합해 **가장 현실적으로 입을 수 있는 선택지**를 제안합니다.

MVP는 **Rule 기반 추천으로 빠르게 검증**하고,  
이후 **ML Inference API(A안)**로 확장합니다.

---

## Key Value
- **기존 옷 활용 극대화**
- **구매 전 옷장 우선 탐색**
- **날씨 기반 현실적 추천**
- **ML 실패 시에도 서비스 유지(Fallback)**

---

## PR rule
	•	디폴트 브랜치: dev
	•	보호 규칙:
	•	main: 직접 push 금지 + PR 필수 + 리뷰 1명
	•	dev: PR 필수 + 리뷰 1명(가볍게)
---

## MVP Scope

### Included
- ClosetItem 등록/조회/수정/삭제
- Today Weather 조회
- Today Recommend
    - Rule 기반 1차 추천
    - ML API(A안) 2차 확장
- WearLog(추천/착용 기록)
- 회원가입/로그인(JWT)

### Excluded (이번 범위 아님)
- 이미지 자동 라벨링 고도화
- 고급 개인화(장기 학습)
- 복잡한 알림/캘린더 연동

---

## Tech Stack

| Layer | Stack |
|------|------|
| Frontend | React |
| Backend | Java 17, Spring Boot 3.x, Spring Data JPA |
| DB | PostgreSQL|
| ML  | Python 3.11, Inference API |
| Infra | Docker, docker-compose |

---

## Architecture (MVP)

1. 사용자가 옷을 **ClosetItem**으로 등록
2. 백엔드가 **Today Weather** 조회
3. 추천 요청 시
    - ML API 정상 → **ML 기반 추천**
    - ML API 실패/지연 → **Rule 기반 추천 자동 fallback**
4. 결과는 **WearLog**로 저장

---

## Repository Structure

```bash
project-root/
├── frontend/                        # 프론트 1명 담당 영역
│   ├── web/                         # React (웹)
│   │   ├── src/
│   │   │   ├── pages/              # 라우트 단위 화면
│   │   │   │   ├── Main/           # 1. 메인 화면
│   │   │   │   ├── Auth/           # 2. 로그인/소셜 로그인 화면
│   │   │   │   ├── Closet/         # 3. 옷 등록 + 내 옷장
│   │   │   │   ├── Checklist/      # 4. 오늘 체크리스트 입력
│   │   │   │   ├── Preview/        # 5. 날씨 + 내 옷장(6개 썸네일 + [더보기])
│   │   │   │   ├── OutfitDetail/   # 6. 옷 상세 페이지
│   │   │   │   ├── Feedback/       # 7. 오늘 코디 피드백(별 5개)
│   │   │   │   ├── History/        # 8. 오늘 옷 추천 결과(히스토리)
│   │   │   │   └── Dashboard/      # 9. 대시보드
│   │   │   │
│   │   │   ├── features/           # 화면별 비즈니스 로직 묶음
│   │   │   │   ├── main/
│   │   │   │   ├── auth/
│   │   │   │   ├── closet/
│   │   │   │   ├── checklist/
│   │   │   │   ├── preview/
│   │   │   │   ├── outfitDetail/
│   │   │   │   ├── feedback/
│   │   │   │   ├── history/
│   │   │   │   └── dashboard/
│   │   │   │
│   │   │   ├── components/         # 공용 UI 컴포넌트
│   │   │   │   ├── layout/
│   │   │   │   ├── common/
│   │   │   │   └── cards/
│   │   │   │
│   │   │   ├── api/                # axios/fetch 클라이언트
│   │   │   ├── hooks/
│   │   │   ├── store/
│   │   │   ├── styles/
│   │   │   └── utils/
│   │   ├── public/
│   │   ├── tests/
│   │   └── package.json
│   │
│   └── android/                    # 필요 시 (모바일 앱 확장용)
│
├── backend/                        # 백엔드 1명 담당 (Java + Spring Boot + JPA + Security)
│   ├── build.gradle                # 또는 pom.xml
│   └── src/
│       ├── main/
│       │   ├── java/com/team/codion/
│       │   │   ├── CodionApplication.java
│       │   │   │
│       │   │   ├── config/         # 공통 설정 (Swagger, CORS, Security 등)
│       │   │   │   ├── SecurityConfig.java      # 🔐 Spring Security 설정
│       │   │   │   ├── OpenApiConfig.java       # Swagger / OpenAPI 설정
│       │   │   │   └── WebConfig.java           # CORS 등 (필요 시)
│       │   │   │
│       │   │   ├── security/       # 🔐 시큐리티/소셜 로그인 컴포넌트
│       │   │   │   ├── CustomOAuth2UserService.java
│       │   │   │   ├── OAuth2SuccessHandler.java      # (선택) 로그인 성공 처리
│       │   │   │   ├── OAuth2FailureHandler.java      # (선택) 로그인 실패 처리
│       │   │   │   └── JwtTokenProvider.java          # (선택) JWT 사용 시
│       │   │   │
│       │   │   ├── common/         # 공통 유틸/베이스/에러
│       │   │   │   ├── api/
│       │   │   │   │   └── ApiResponseDto.java       # 공통 응답 포맷
│       │   │   │   ├── entity/
│       │   │   │   │   └── BaseEntity.java           # createdAt, updatedAt 등
│       │   │   │   └── error/
│       │   │   │       ├── ErrorCode.java
│       │   │   │       └── GlobalExceptionHandler.java
│       │   │   │
│       │   │   ├── api/            # 컨트롤러 + DTO (외부 노출 전용)
│       │   │   │   ├── controller/
│       │   │   │   │   ├── MainController.java       # 메인/홈 요약
│       │   │   │   │   ├── AuthController.java       # 로그인/토큰 관련
│       │   │   │   │   ├── ClosetController.java     # 옷 등록/옷장
│       │   │   │   │   ├── ChecklistController.java  # 오늘 체크리스트
│       │   │   │   │   ├── PreviewController.java    # 날씨 + 옷장 썸네일 6개
│       │   │   │   │   ├── OutfitController.java     # 상세 코디/오늘 추천 생성
│       │   │   │   │   ├── FeedbackController.java   # 피드백 저장
│       │   │   │   │   ├── HistoryController.java    # 오늘/과거 추천 히스토리
│       │   │   │   │   └── DashboardController.java  # 대시보드 통계
│       │   │   │   │
│       │   │   │   └── dto/
│       │   │   │       ├── main/
│       │   │   │       ├── auth/
│       │   │   │       ├── closet/
│       │   │   │       ├── checklist/
│       │   │   │       ├── preview/
│       │   │   │       ├── outfit/
│       │   │   │       ├── feedback/
│       │   │   │       ├── history/
│       │   │   │       └── dashboard/
│       │   │   │
│       │   │   ├── domain/         # JPA 엔티티 (ORM 핵심)
│       │   │   │   ├── user/
│       │   │   │   │   ├── User.java
│       │   │   │   │   └── UserProfile.java
│       │   │   │   ├── closet/
│       │   │   │   │   └── ClosetItem.java
│       │   │   │   └── outfit/
│       │   │   │       ├── Outfit.java              # 추천 코디 단위
│       │   │   │       ├── WearLog.java             # 실제 착용 기록
│       │   │   │       └── Recommendation.java      # 추천 결과 저장(요약)
│       │   │   │
│       │   │   ├── repository/     # Spring Data JPA 리포지토리
│       │   │   │   ├── user/
│       │   │   │   │   └── UserRepository.java
│       │   │   │   ├── closet/
│       │   │   │   │   └── ClosetItemRepository.java
│       │   │   │   └── outfit/
│       │   │   │       ├── OutfitRepository.java
│       │   │   │       ├── WearLogRepository.java
│       │   │   │       └── RecommendationRepository.java
│       │   │   │
│       │   │   ├── service/        # 비즈니스 로직
│       │   │   │   ├── main/
│       │   │   │   │   └── MainService.java
│       │   │   │   ├── auth/
│       │   │   │   │   └── AuthService.java
│       │   │   │   ├── closet/
│       │   │   │   │   └── ClosetService.java
│       │   │   │   ├── checklist/
│       │   │   │   │   └── ChecklistService.java
│       │   │   │   ├── preview/
│       │   │   │   │   └── PreviewService.java
│       │   │   │   ├── outfit/
│       │   │   │   │   └── OutfitService.java
│       │   │   │   ├── feedback/
│       │   │   │   │   └── FeedbackService.java
│       │   │   │   ├── history/
│       │   │   │   │   └── HistoryService.java
│       │   │   │   └── dashboard/
│       │   │   │       └── DashboardService.java
│       │   │   │
│       │   │   └── external/       # 공공데이터 / 외부 서버 클라이언트
│       │   │       ├── weather/
│       │   │       │   ├── KmaWeatherClient.java
│       │   │       │   └── KmaWeatherResponseDto.java
│       │   │       └── air/
│       │   │           ├── AirKoreaClient.java
│       │   │           └── AirKoreaResponseDto.java
│       │   │
│       │   └── resources/
│       │       ├── application.yml               # 공통 설정 (DB, 포트, JPA, springdoc 등)
│       │       ├── application-oauth-example.yml # 🔐 OAuth 설정 예시 (깃에 커밋 O)
│       │       ├── application-local.yml         # 로컬용 (깃에 커밋 X)
│       │       ├── application-oauth.yml         # 실제 키 (깃에 커밋 X)
│       │       └── data.sql                      # 선택: 초기 데이터
│       │
│       └── test/java/com/team/codion/
│           ├── controller/
│           └── service/
│
├── ml/                             # AI 2명 담당 영역
│   ├── data/
│   │   ├── raw/
│   │   └── processed/
│   ├── features/
│   ├── models/
│   │   ├── architectures/
│   │   └── inference.py
│   ├── experiments/
│   │   ├── notebooks/
│   │   ├── baselines/
│   │   └── logs/
│   ├── pipeline/
│   │   ├── preprocess.py
│   │   ├── train.py
│   │   ├── evaluate.py
│   │   └── export_model.py
│   ├── configs/
│   └── artifacts/
│       ├── model.pt
│       └── scaler.pkl
│
├── docs/
│   ├── ERD.png
│   ├── API_SPEC.md
│   ├── MODEL_DESIGN.md
│   ├── FEATURE_SPEC.md
│   ├── SCREEN_FLOW.md
│   └── SECURITY_SPEC.md          # 시큐리티/소셜 로그인 흐름 정리용
│
├── infra/
│   ├── docker-compose.yml        # DB, 백엔드, (필요 시) ML 서비스
│   └── env.example               # DB/OAuth 환경변수 예시
│
└── README.md